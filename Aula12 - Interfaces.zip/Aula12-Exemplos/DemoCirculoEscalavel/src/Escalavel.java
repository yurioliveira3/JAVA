
public interface Escalavel {
	void Amplia(double escala);
}

// Ou Escalavel pode ser uma classe abstrata!

//public abstract class Escalavel {
//	abstract void Amplia(double escala);
//}
