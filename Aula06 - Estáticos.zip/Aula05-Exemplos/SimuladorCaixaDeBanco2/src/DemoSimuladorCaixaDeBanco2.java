
public class DemoSimuladorCaixaDeBanco2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimuladorCaixaDeBanco2 c1 = new SimuladorCaixaDeBanco2(1);
		SimuladorCaixaDeBanco2 c2 = new SimuladorCaixaDeBanco2(2);
		SimuladorCaixaDeBanco2 c3 = new SimuladorCaixaDeBanco2(3);
		SimuladorCaixaDeBanco2 c4 = new SimuladorCaixaDeBanco2(4);
		SimuladorCaixaDeBanco2 c5 = new SimuladorCaixaDeBanco2(5);
		c1.iniciaAtendimento();
		c2.iniciaAtendimento();
		c3.iniciaAtendimento();
		c4.iniciaAtendimento();
		c5.iniciaAtendimento();
		c1.iniciaAtendimento();
		c2.iniciaAtendimento();
		c3.iniciaAtendimento();
		c1.iniciaAtendimento();
		c2.iniciaAtendimento();
		c1.iniciaAtendimento();
		c1.iniciaAtendimento();
		c1.iniciaAtendimento();
		c1.iniciaAtendimento();
	}

}
