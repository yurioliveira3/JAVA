
public class ConstantesMatematicas {
	// A raiz quadrada de 2
	final static public double raizDe2 = 1.4142135623730950488;
	// A raiz quadrada de 3
	final static public double raizDe3 = 1.7320508075688772935;
	// A raiz quadrada de 5
	final static public double raizDe5 = 2.2360679774997896964;
	// A raiz quadrada de 6
	final static public double raizDe6 = raizDe2*raizDe3;
}
