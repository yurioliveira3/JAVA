
public class ConversaoDeUnidadesDeComprimento {
	public static double polegadasParaCentimetros(double polegadas) {
		double centimetros = polegadas * 2.54;
		return centimetros;
	}
	public static double pesParaCentimetros(double pes) {
		double centimetros = pes * 30.48;
		return centimetros;
	}
	public static double milhasParaQuilometros(double milhas) {
		double quilometros = milhas * 1.609;
		return quilometros;
	}
}
