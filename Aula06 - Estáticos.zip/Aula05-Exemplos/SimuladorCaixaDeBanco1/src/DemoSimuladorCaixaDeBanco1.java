
public class DemoSimuladorCaixaDeBanco1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimuladorCaixaDeBanco1 c1 = new SimuladorCaixaDeBanco1(1);
		SimuladorCaixaDeBanco1 c2 = new SimuladorCaixaDeBanco1(2);
		SimuladorCaixaDeBanco1 c3 = new SimuladorCaixaDeBanco1(3);
		SimuladorCaixaDeBanco1 c4 = new SimuladorCaixaDeBanco1(4);
		SimuladorCaixaDeBanco1 c5 = new SimuladorCaixaDeBanco1(5);
		c1.iniciaAtendimento();
		c2.iniciaAtendimento();
		c3.iniciaAtendimento();
		c4.iniciaAtendimento();
		c5.iniciaAtendimento();
		c1.iniciaAtendimento();
		c2.iniciaAtendimento();
		c3.iniciaAtendimento();
		c1.iniciaAtendimento();
		c2.iniciaAtendimento();
		c1.iniciaAtendimento();
		c1.iniciaAtendimento();
		c1.iniciaAtendimento();
		c1.iniciaAtendimento();
	}

}
