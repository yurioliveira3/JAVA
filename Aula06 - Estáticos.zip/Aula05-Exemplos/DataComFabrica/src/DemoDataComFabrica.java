
public class DemoDataComFabrica {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataComFabrica natal2000 = DataComFabrica.Natal(2000);
		DataComFabrica natal2004 = DataComFabrica.Natal(2004);
		DataComFabrica natal2008 = DataComFabrica.Natal(2008);
		System.out.println(natal2000);
		System.out.println(natal2004);
		System.out.println(natal2008);
	}
}
